Common files:

webgl-utils.js: standard utilities from google to set up a webgl context

MV.js: our matrix/vector package. Documentation on website

initShaders.js: functions to initialize shaders in the html file

initShaders2.js: functions to initialize shaders that are in separate files

Sylvester.js was written by James Coglan and is a general vector and matrix mathematics library for JavaScript.

The JavaScript library glMatrix was written by Brandon Jones. It was written primarily for WebGL and is quite similar to WebGL-mjs.
